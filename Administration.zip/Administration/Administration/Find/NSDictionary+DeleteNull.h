//
//  NSDictionary+DeleteNull.h
//  Administration
//
//  Created by zhang on 2017/2/25.
//  Copyright © 2017年 九尾狐. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (DeleteNull)
+(id)changeType:(id)myObj;  
@end
