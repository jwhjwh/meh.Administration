//
//  MessagexqController.h
//  Administration
//
//  Created by zhang on 2017/2/22.
//  Copyright © 2017年 九尾狐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessagexqController : UIViewController
@property (nonatomic,retain)NSString *flagStr;
@property (nonatomic,retain)NSString *IdStr;
@property (nonatomic,retain)NSString *codeStr;
@property (nonatomic,retain)NSString *sortStr;
@property (nonatomic,retain)NSString *remarkStr;
@end
