//
//  ZYJHeadLineModel.h
//  ZYJHeadLineView
//
//  Created by 张彦杰 on 16/12/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZYJHeadLineModel : NSObject
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSString *title;
@end
