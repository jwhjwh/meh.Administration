//
//  ZYJHeadLineModel.m
//  ZYJHeadLineView
//
//  Created by 张彦杰 on 16/12/19.
//  Copyright © 2016年 apple. All rights reserved.
//

#import "ZYJHeadLineModel.h"

@implementation ZYJHeadLineModel

@end
