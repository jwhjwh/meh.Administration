//
//  GongModel.m
//  Administration
//
//  Created by zhang on 2017/2/21.
//  Copyright © 2017年 九尾狐. All rights reserved.
//

#import "GongModel.h"

@implementation GongModel
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    
}

-(id)valueForUndefinedKey:(NSString *)key{
    return nil;
    
}
@end
