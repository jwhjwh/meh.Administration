//
//  mesagexqCell.h
//  Administration
//
//  Created by 费腾 on 17/2/22.
//  Copyright © 2017年 九尾狐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface mesagexqCell : UITableViewCell
@property (nonatomic,retain)UILabel *biaoLabel;
@property (nonatomic,retain)UIButton *button;
@property (nonatomic,retain)UITextView *TextField;
@end
