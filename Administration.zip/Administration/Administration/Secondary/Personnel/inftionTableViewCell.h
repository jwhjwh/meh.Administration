//
//  inftionTableViewCell.h
//  Administration
//
//  Created by zhang on 2017/2/25.
//  Copyright © 2017年 九尾狐. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface inftionTableViewCell : UITableViewCell
@property(nonatomic,retain)UILabel *mingLabel;
@property (nonatomic,retain)UILabel *xingLabel;
@end
